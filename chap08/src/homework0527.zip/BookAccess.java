package homework0527;

public interface BookAccess {

}
