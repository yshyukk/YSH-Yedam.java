package homework0527;

public class Book {

}
