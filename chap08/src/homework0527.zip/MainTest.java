package homework0527;

public class MainTest {

	public static void main(String[] args) {
		

	}

}
