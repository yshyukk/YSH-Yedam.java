package homework0527;

public class BookSystem implements BookProgram {

}
